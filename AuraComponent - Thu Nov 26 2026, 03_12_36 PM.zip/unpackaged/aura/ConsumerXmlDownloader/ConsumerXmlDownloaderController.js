({
    handleScriptsLoaded : function(
        component,
        event,
        helper
    ) {
        component.set(
            "v.jsZipLoaded",
            true
        );
        
        component.set(
            "v.message",
            "ZIP library loaded."
        );
    },
    
    downloadXml : function(
        component,
        event,
        helper
    ) {
        var reportId =
            component.get(
                "v.consumerReportId"
            );
        
        if (!reportId) {
            component.set(
                "v.message",
                "Enter a Consumer Report ID."
            );
            return;
        }
        
        component.set(
            "v.isLoading",
            true
        );
        
        var action =
            component.get(
                "c.getXml"
            );
        
        action.setParams({
            consumerReportId:
            reportId
        });
        
        action.setCallback(
            this,
            function(response) {
                
                component.set(
                    "v.isLoading",
                    false
                );
                
                var state =
                    response.getState();
                
                if (state === "SUCCESS") {
                    
                    var result =
                        response.getReturnValue();
                    
                    helper.downloadFile(
                        result.fileName,
                        result.base64Content
                    );
                    
                    component.set(
                        "v.message",
                        "Downloaded " +
                        result.fileName
                    );
                    
                } else {
                    
                    var errors =
                        response.getError();
                    
                    var message =
                        "XML download failed.";
                    
                    if (
                        errors &&
                        errors[0] &&
                        errors[0].message
                    ) {
                        message =
                            errors[0].message;
                    }
                    
                    component.set(
                        "v.message",
                        message
                    );
                }
            }
        );
        
        $A.enqueueAction(
            action
        );
    },
    
    downloadFiveXml : function(
        component,
        event,
        helper
    ) {
        if (!component.get("v.jsZipLoaded")) {
            component.set(
                "v.message",
                "ZIP library is not loaded."
            );
            return;
        }
        
        component.set(
            "v.isLoading",
            true
        );
        
        component.set(
            "v.message",
            "Preparing XML files..."
        );
        
        var startDate =
            component.get(
                "v.startDate"
            );
        
        var endDate =
            component.get(
                "v.endDate"
            );
        
        if (!startDate || !endDate) {
            component.set(
                "v.message",
                "Select Start Date and End Date."
            );
            
            component.set(
                "v.isLoading",
                false
            );
            
            return;
        }
        
        var action =
            component.get(
                "c.getFiveXmlFiles"
            );
        
        console.log("ACTION =", action);
        
        if (!action) {
            component.set(
                "v.isLoading",
                false
            );
            
            component.set(
                "v.message",
                "ERROR: getFiveXmlFiles Apex action was not found."
            );
            
            return;
        }    
        
        action.setParams({
            startDate: startDate,
            endDate: endDate
        });
        
        action.setCallback(
            this,
            function(response) {
                
                component.set(
                    "v.isLoading",
                    false
                );
                
                var state =
                    response.getState();
                
                if (state === "SUCCESS") {
                    
                    var files =
                        response.getReturnValue();
                    
                    if (!files || files.length === 0) {
                        component.set(
                            "v.message",
                            "No XML files found."
                        );
                        return;
                    }
                    
                    var zip =
                        new JSZip();
                    
                    files.forEach(
                        function(file) {
                            zip.file(
                                file.fileName,
                                file.base64Content,
                                {
                                    base64: true
                                }
                            );
                        }
                    );
                    
                    zip.generateAsync({
                        type: "blob"
                    }).then(
                        function(content) {
                            
                            var link =
                                document.createElement("a");
                            
                            var url =
                                URL.createObjectURL(content);
                            
                            link.href = url;
                            
                            var now = new Date();
                            
                            var timestamp =
                                now.getFullYear() +
                                "-" +
                                String(now.getMonth() + 1).padStart(2, "0") +
                                "-" +
                                String(now.getDate()).padStart(2, "0") +
                                "_" +
                                String(now.getHours()).padStart(2, "0") +
                                "-" +
                                String(now.getMinutes()).padStart(2, "0") +
                                "-" +
                                String(now.getSeconds()).padStart(2, "0");
                            
                            link.download =
                                "Consumer_XML_" +
                                timestamp +
                                ".zip";
                            
                            document.body.appendChild(
                                link
                            );
                            
                            link.click();
                            
                            document.body.removeChild(
                                link
                            );
                            
                            URL.revokeObjectURL(
                                url
                            );
                            
                            component.set(
                                "v.message",
                                "Downloaded " +
                                files.length +
                                " XML files as ZIP."
                            );
                        }
                    );
                    
                } else {
                    
                    var errors =
                        response.getError();
                    
                    var message =
                        "ZIP download failed.";
                    
                    if (
                        errors &&
                        errors[0] &&
                        errors[0].message
                    ) {
                        message =
                            errors[0].message;
                    }
                    
                    component.set(
                        "v.message",
                        message
                    );
                }
            }
        );
        
        $A.enqueueAction(
            action
        );
    }
})