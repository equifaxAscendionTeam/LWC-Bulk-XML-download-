import { LightningElement, track, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { loadScript } from 'lightning/platformResourceLoader';
import papaparse from '@salesforce/resourceUrl/papaparse';

import getUploadOptions from '@salesforce/apex/TDT_CSVImportController.getUploadOptions';
import getRequiredFields from '@salesforce/apex/TDT_CSVImportController.getRequiredFields';
import createAccounts from '@salesforce/apex/TDT_CSVImportController.createAccountsinChunksV2';
import createContacts from '@salesforce/apex/TDT_CSVImportController.createContactsInChunksV2';
import startReportProcessingBatch from '@salesforce/apex/TDT_CSVImportController.startReportProcessingBatch';
import getTargetRecordId from '@salesforce/apex/TDT_CSVImportController.getTargetRecordId';
import getInputFieldsMapping from '@salesforce/apex/TDT_CSVImportController.getFieldMappings';
import getMappingTemplates from '@salesforce/apex/TDT_CSVImportController.getMappingTemplates';
import saveMappingTemplate from '@salesforce/apex/TDT_CSVImportController.saveMappingTemplate';

const CHUNK_SIZE = 100;
const PREVIEW_LIMIT = 10;
const MAX_CLIENT_ERRORS = 100;
const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024;
const IMPORTED_DISPLAY_LIMIT = 200;

export default class CsvAccountUploader extends NavigationMixin(LightningElement) {
    @track options = [];
    @track progress = 0;
    @track showProgress = false;
    @track fileName = '';
    @track skipReportPull = false;

    @track csvHeaders = [];
    @track mappingRows = [];
    @track mapping = {};
    @track salesforceFieldOptions = [];
    @track requiredFieldApiNames = [];

    @track templateOptions = [];
    @track selectedTemplateId = '';

    @track validationSummary = {
        totalRows: 0,
        validRows: 0,
        errorCount: 0,
        errorMessage: ''
    };
    @track validationErrors = [];
    @track previewColumns = [];
    @track previewRows = [];

    @track importedColumns = [];
    @track importedRows = [];
    importedSearchTerm = '';

    @track processedCount = 0;
    @track successCount = 0;
    @track failureCount = 0;
    @track importErrors = [];

    selectedOption;
    file;
    parsedRows = [];
    totalRows = 0;
    isProcessing = false;
    papaInitialized = false;
    creditPolicyRecordID;
    currentChunkStartRowNumber = 2;
    showTemplateModal = false;
    newTemplateName = '';
    hasValidationRun = false;
    hasPreview = false;
    previewLimit = PREVIEW_LIMIT;
    currentTemplateMapping = null;

    connectedCallback() {
        loadScript(this, papaparse)
            .then(() => {
                this.papaInitialized = true;
            })
            .catch((err) => {
                console.error('PapaParse load failed', err);
                this.showToast('Error', 'Unable to load CSV parser.', 'error');
            });
    }

    @wire(getUploadOptions)
    wiredOptions({ data, error }) {
        if (data) {
            this.options = data;
            console.log(JSON.stringify(this.options));
        } else if (error) {
            this.showToast('Error', this.getErrorMessage(error), 'error');
        }
    }

    get derivedRecordType() {
        if (!this.selectedOption) return null;
        const lower = this.selectedOption.toLowerCase();
        if (lower.includes('commercial') || lower.includes('equifax business verification')) {
            return 'Account';
        }
        if (lower.includes('consumer')) {
            return 'Contact';
        }
        return null;
    }

    getCountryByReportType() {
        const countryMap = {
            'Commercial': 'United States',
            'Canada Commercial Report': 'Canada',
            'USA Consumer Report': 'United States',
            'Canada Consumer Report': 'Canada',
            'Equifax Business Verification': 'United States'
        };
        return countryMap[this.selectedOption] || null;
    }

    get hasCsvHeaders() {
        return this.csvHeaders.length > 0;
    }

    get hasValidationErrors() {
        return this.validationErrors.length > 0;
    }

    get hasImportErrors() {
        return this.importErrors.length > 0;
    }

    get hasImportedRecords() {
        return this.importedRows.length > 0;
    }

    get filteredImportedRows() {
        const term = (this.importedSearchTerm || '').trim().toLowerCase();
        if (!term) {
            return this.importedRows;
        }
        return this.importedRows.filter((row) => row.searchName.includes(term));
    }

    get hasFilteredImportedRows() {
        return this.filteredImportedRows.length > 0;
    }

    get importedCountLabel() {
        const shown = this.filteredImportedRows.length;
        const total = this.importedRows.length;
        return shown === total
            ? `${total} record(s)`
            : `Showing ${shown} of ${total} record(s)`;
    }

    get importedSearchLabel() {
        return this.derivedRecordType === 'Contact'
            ? 'Search by Last Name'
            : 'Search by Account Name';
    }

    handleImportedSearch(event) {
        this.importedSearchTerm = event.target.value || '';
    }

    get isFileUploadDisabled() {
        return !this.selectedOption || this.isProcessing;
    }

    get isTemplateDisabled() {
        return !this.selectedOption || this.isProcessing;
    }

    get isSaveTemplateDisabled() {
        return !this.hasCsvHeaders || this.isProcessing || !this.hasAtLeastOneMapping;
    }

    get isValidateDisabled() {
        return !this.file || !this.hasCsvHeaders || this.isProcessing;
    }

    get isStartDisabled() {
        return !this.file ||
            !this.hasCsvHeaders ||
            this.isProcessing ||
            !this.hasAtLeastOneMapping ||
            !this.hasValidationRun ||
            this.hasValidationErrors;
    }

    get hasAtLeastOneMapping() {
        return Object.values(this.mapping).some((value) => value);
    }

    get unmappedColumns() {
        // Only flag rows the user can actually map (skip disabled/auto-concatenated rows
        // like Middle Name or Mailing Street parts, since those are handled separately).
        return this.mappingRows.filter((row) => !row.disabled && !row.sfField);
    }

    get hasUnmappedColumns() {
        return this.unmappedColumns.length > 0;
    }

    get unmappedColumnsMessage() {
        const names = this.unmappedColumns.map((row) => row.csvField).join(', ');
        return `${names} column(s) are not mapped to a Salesforce field and will be ignored for insert`;
    }

    get salesforceFieldOptionsWithDeselect() {
        return [
            { label: '-- None --', value: '' },
            ...this.salesforceFieldOptions
        ];
    }

    handlePicklistChange(event) {
        this.selectedOption = event.detail.value;
        this.resetFileState();

        this.loadSalesforceFieldOptions();
        this.loadMappingTemplates();
        this.loadRequiredFields();
        if (this.selectedOption === 'Commercial' ||
            this.selectedOption === 'Canada Commercial Report') {
            getTargetRecordId({ selectedOption: this.selectedOption })
                .then((result) => {
                    this.creditPolicyRecordID = result;
                })
                .catch((error) => {
                    this.creditPolicyRecordID = null;
                    this.showToast('Warning', this.getErrorMessage(error), 'warning');
                });
        } else {
            this.creditPolicyRecordID = null;
        }
    }

    handleCheckboxChange(event) {
        this.skipReportPull = event.target.checked;
    }

    loadSalesforceFieldOptions() {
        getInputFieldsMapping({ selectedObjType: this.selectedOption })
            .then((result) => {
                this.salesforceFieldOptions = result
                    ? result.map((item) => ({
                        label: item.Label,
                        value: item.APIName
                    }))
                    : [];
            })
            .catch((error) => {
                this.salesforceFieldOptions = [];
                this.showToast('Error', this.getErrorMessage(error), 'error');
            });
    }

    loadRequiredFields() {
        getRequiredFields({ selectedObjType: this.selectedOption })
            .then((result) => {
                this.requiredFieldApiNames = (result || '')
                    .split(',')
                    .map((field) => field.trim())
                    .filter(Boolean);
            })
            .catch((error) => {
                this.requiredFieldApiNames = [];
                this.showToast('Error', this.getErrorMessage(error), 'error');
            });
    }

    loadMappingTemplates() {
        getMappingTemplates({ selectedOption: this.selectedOption })
            .then((result) => {
                this.templateOptions = (result || []).map((item) => ({
                    label: item.name,
                    value: item.id
                }));
            })
            .catch((error) => {
                this.templateOptions = [];
                this.showToast('Error', this.getErrorMessage(error), 'error');
            });
    }

    handleFileUpload(event) {
        const selectedFile = event.target.files && event.target.files[0];

        if (!selectedFile) return;

        if (!selectedFile.name.toLowerCase().endsWith('.csv')) {
            this.showToast('Error', 'Upload CSV only.', 'error');
            return;
        }

        if (selectedFile.size > MAX_FILE_SIZE_BYTES) {
            this.showToast(
                'Error',
                'The CSV file exceeds the 10 MB browser validation limit.',
                'error'
            );
            return;
        }

        if (!this.papaInitialized || typeof Papa === 'undefined') {
            this.showToast('Error', 'CSV parser is still loading. Please try again.', 'error');
            return;
        }

        this.file = selectedFile;
        this.fileName = selectedFile.name;
        this.resetValidationAndResults();

        Papa.parse(selectedFile, {
            header: true,
            skipEmptyLines: true,
            complete: (result) => {
                if (result.errors && result.errors.length > 0) {
                    const parserErrors = result.errors
                        .slice(0, MAX_CLIENT_ERRORS)
                        .map((error, index) => ({
                            key: `parser-${index}`,
                            rowNumber: (error.row || 0) + 2,
                            message: error.message || 'CSV parsing error'
                        }));

                    this.validationErrors = parserErrors;
                    this.validationSummary = {
                        totalRows: 0,
                        validRows: 0,
                        errorCount: result.errors.length,
                        errorMessage: 'The CSV contains parsing errors. Please correct the file and upload it again.'
                    };
                    this.hasValidationRun = true;
                    this.parsedRows = [];
                    this.csvHeaders = result.meta.fields || [];
                    this.buildMappingRows();
                    return;
                }

                this.csvHeaders = (result.meta.fields || [])
                    .map((header) => (header || '').trim());

                this.parsedRows = result.data || [];
                this.totalRows = this.parsedRows.length;

                if (!this.csvHeaders.length) {
                    this.showToast('Error', 'The CSV does not contain any headers.', 'error');
                    this.resetFileState();
                    return;
                }

                const duplicateHeaders = this.findDuplicateHeaders(this.csvHeaders);
                if (duplicateHeaders.length) {
                    this.validationErrors = [{
                        key: 'duplicate-headers',
                        rowNumber: 1,
                        message: `Duplicate CSV header(s): ${duplicateHeaders.join(', ')}`
                    }];
                    this.validationSummary = {
                        totalRows: this.totalRows,
                        validRows: 0,
                        errorCount: duplicateHeaders.length,
                        errorMessage: 'Duplicate headers must be corrected before processing.'
                    };
                    this.hasValidationRun = true;
                }

                this.buildMappingRows();
                if (this.currentTemplateMapping) {
                    this.applyTemplateMapping(this.currentTemplateMapping);
                }
            },
            error: (error) => {
                this.showToast('Error', error?.message || 'Failed to read CSV.', 'error');
                this.resetFileState();
            }
        });
    }

    buildMappingRows() {
        const prunedMapping = {};
        this.csvHeaders.forEach((header) => {
            if (this.mapping[header]) {
                prunedMapping[header] = this.mapping[header];
            }
        });
        this.mapping = prunedMapping;

        const mailingStreetParts = [
            'streetnumber',
            'streetname',
            'streettypedirectionalapartmentnumber'
        ];

        this.mappingRows = this.csvHeaders.map((header) => {
            const normalizedHeader = this.normalize(header);

            const isMiddleName = this.derivedRecordType === 'Contact' &&
                normalizedHeader === 'middlename';

            const isMailingStreetPart = this.derivedRecordType === 'Contact' &&
                mailingStreetParts.includes(normalizedHeader);

            const disabled = isMiddleName || isMailingStreetPart;
            const suggestedField = disabled ? '' : this.findAutomaticMapping(header);

            if (suggestedField) {
                this.mapping[header] = suggestedField;
            }

            return {
                csvField: header,
                sfField: suggestedField || '',
                disabled,
                autoMapped: !!suggestedField,
                hint: isMiddleName
                    ? 'Concatenated into First Name automatically'
                    : isMailingStreetPart
                        ? 'Concatenated into Mailing Street automatically'
                        : ''
            };
        });
    }

    findAutomaticMapping(csvHeader) {
        const normalizedHeader = this.normalize(csvHeader);

        const exact = this.salesforceFieldOptions.find(
            (option) => this.normalize(option.value) === normalizedHeader
        );
        if (exact) return exact.value;

        const labelMatch = this.salesforceFieldOptions.find(
            (option) => this.normalize(option.label) === normalizedHeader
        );
        if (labelMatch) return labelMatch.value;

        const aliases = {
            accountname: ['name', 'company', 'companyname', 'customername', 'businessname'],
            name: ['accountname', 'company', 'companyname', 'customername', 'businessname'],
            firstname: ['givenname', 'first'],
            lastname: ['surname', 'familyname', 'last'],
            phone: ['phonenumber', 'telephone', 'mobilephone'],
            billingstreet: ['street', 'address', 'billingaddress', 'streetaddress'],
            mailingstreet: ['street', 'address', 'mailingaddress', 'streetaddress'],
            billingcity: ['city', 'town'],
            mailingcity: ['city', 'town'],
            billingstate: ['state', 'province', 'region'],
            mailingstate: ['state', 'province', 'region'],
            billingpostalcode: ['postalcode', 'postcode', 'zipcode', 'zip'],
            mailingpostalcode: ['postalcode', 'postcode', 'zipcode', 'zip'],
            birthdate: ['dateofbirth', 'dob'],
            forseva1__tax_id__c: ['taxid', 'taxnumber', 'taxno'],
            forseva1__equifax_file_number__c: ['equifaxid', 'equifaxfilenumber', 'fileid']
        };

        const field = this.salesforceFieldOptions.find((option) => {
            const normalizedField = this.normalize(option.value);
            const normalizedLabel = this.normalize(option.label);
            const candidates = aliases[normalizedField] || aliases[normalizedLabel] || [];
            return candidates.includes(normalizedHeader);
        });

        return field ? field.value : '';
    }

    handleMappingChange(event) {
        const csvField = event.target.dataset.csv;
        const sfField = event.detail.value;

        const duplicateTarget = sfField && Object.entries(this.mapping).some(
            ([key, value]) => key !== csvField && value === sfField
        );

        if (duplicateTarget) {
            this.showToast(
                'Error',
                `Salesforce field "${this.getFieldLabel(sfField)}" is already mapped to another CSV column.`,
                'error'
            );
            return;
        }

        this.mapping = {
            ...this.mapping,
            [csvField]: sfField
        };

        this.mappingRows = this.mappingRows.map((row) =>
            row.csvField === csvField
                ? { ...row, sfField, autoMapped: false }
                : row
        );

        this.resetValidationAndResults();
    }

    handleTemplateChange(event) {
        const templateId = event.detail.value;
        this.selectedTemplateId = templateId;

        if (!templateId) {
            this.currentTemplateMapping = null;
            return;
        }

        getMappingTemplates({ selectedOption: this.selectedOption })
            .then((result) => {
                const selected = (result || []).find((item) => item.id === templateId);
                if (!selected) return;

                const templateMapping = JSON.parse(selected.mappingJson);
                this.currentTemplateMapping = templateMapping;
                this.applyTemplateMapping(templateMapping);

                this.resetValidationAndResults();
                this.showToast('Success', 'Mapping template applied.', 'success');
            })
            .catch((error) => {
                this.showToast('Error', this.getErrorMessage(error), 'error');
            });
    }

    applyTemplateMapping(templateMapping) {
        const applicable = {};

        this.csvHeaders.forEach((header) => {
            if (templateMapping[header]) {
                applicable[header] = templateMapping[header];
            } else {
                const normalized = this.normalize(header);
                const templateKey = Object.keys(templateMapping).find(
                    (key) => this.normalize(key) === normalized
                );
                if (templateKey) {
                    applicable[header] = templateMapping[templateKey];
                }
            }
        });

        this.mapping = { ...this.mapping, ...applicable };
        this.mappingRows = this.mappingRows.map((row) => ({
            ...row,
            sfField: row.disabled ? '' : (applicable[row.csvField] || row.sfField),
            autoMapped: !!applicable[row.csvField]
        }));
    }

    clearTemplate() {
        this.selectedTemplateId = '';
        this.currentTemplateMapping = null;
    }

    openSaveTemplateModal() {
        this.newTemplateName = '';
        this.showTemplateModal = true;
    }

    closeSaveTemplateModal() {
        this.showTemplateModal = false;
        this.newTemplateName = '';
    }

    handleTemplateNameChange(event) {
        this.newTemplateName = event.target.value;
    }

    saveTemplate() {
        const templateName = (this.newTemplateName || '').trim();

        if (!templateName) {
            this.showToast('Error', 'Template name is required.', 'error');
            return;
        }

        saveMappingTemplate({
            templateName,
            reportType: this.selectedOption,
            mappingJson: JSON.stringify(this.mapping)
        })
            .then((newTemplateId) => {
                this.closeSaveTemplateModal();
                this.showToast('Success', 'Mapping template saved.', 'success');
                if (newTemplateId) {
                    const alreadyListed = this.templateOptions.some(
                        (option) => option.value === newTemplateId
                    );
                    if (!alreadyListed) {
                        this.templateOptions = [
                            ...this.templateOptions,
                            { label: templateName, value: newTemplateId }
                        ];
                    }
                    this.selectedTemplateId = newTemplateId;
                    this.currentTemplateMapping = JSON.parse(JSON.stringify(this.mapping));
                }
                this.loadMappingTemplates();
            })
            .catch((error) => {
                this.showToast('Error', this.getErrorMessage(error), 'error');
            });
    }

    validateAndPreparePreview() {
        if (!this.file || !this.parsedRows.length) {
            this.showToast('Error', 'Please upload a CSV file containing at least one data row.', 'error');
            return;
        }

        if (!this.hasAtLeastOneMapping) {
            this.showToast('Error', 'Please map at least one CSV field.', 'error');
            return;
        }

        const errors = [];
        const seenRows = new Set();
        const invalidRowNumbers = new Set();
        let validRows = 0;

        if (!this.derivedRecordType) {
            errors.push({
                key: 'record-type',
                rowNumber: null,
                message: 'Unable to determine the Salesforce target object from the selected report type.'
            });
        }

        const mappedTargetFields = Object.values(this.mapping).filter(Boolean);

        this.requiredFieldApiNames.forEach((requiredField) => {
            if (!mappedTargetFields.includes(requiredField)) {
                errors.push({
                    key: `required-field-${requiredField}`,
                    rowNumber: null,
                    message: `${this.getFieldLabel(requiredField)} must be mapped.`
                });
            }
        });

        const duplicateHeaders = this.findDuplicateHeaders(this.csvHeaders);
        duplicateHeaders.forEach((header) => {
            errors.push({
                key: `duplicate-${header}`,
                rowNumber: null,
                message: `Duplicate CSV header: ${header}`
            });
        });

        const targetFieldUsage = {};
        Object.entries(this.mapping).forEach(([csvField, sfField]) => {
            if (!sfField) return;
            targetFieldUsage[sfField] = targetFieldUsage[sfField] || [];
            targetFieldUsage[sfField].push(csvField);
        });

        Object.entries(targetFieldUsage).forEach(([sfField, csvFields]) => {
            if (csvFields.length > 1) {
                errors.push({
                    key: `mapping-${sfField}`,
                    rowNumber: null,
                    message: `${this.getFieldLabel(sfField)} is mapped from multiple CSV columns: ${csvFields.join(', ')}`
                });
            }
        });

        this.parsedRows.forEach((row, index) => {
            const rowNumber = index + 2;
            const record = this.buildRecord(row);

            if (this.isBlankRecord(row)) {
                return;
            }

            this.requiredFieldApiNames.forEach((requiredField) => {
                if (!String(record[requiredField] || '').trim()) {
                    invalidRowNumbers.add(rowNumber);
                    errors.push({
                        key: `row-${rowNumber}-${requiredField}`,
                        rowNumber,
                        message: `${this.getFieldLabel(requiredField)} is required.`
                    });
                }
            });

            if (record.Birthdate && !this.isValidSalesforceDate(record.Birthdate)) {
                invalidRowNumbers.add(rowNumber);
                errors.push({
                    key: `row-${rowNumber}-birthdate`,
                    rowNumber,
                    message: `Invalid Birthdate "${record.Birthdate}". Use MM-DD-YYYY, MM/DD/YYYY, or YYYY-MM-DD.`
                });
            }

            const duplicateKey = this.getDuplicateRowKey(record);
            if (duplicateKey) {
                if (seenRows.has(duplicateKey)) {
                    invalidRowNumbers.add(rowNumber);
                    errors.push({
                        key: `row-${rowNumber}-duplicate`,
                        rowNumber,
                        message: 'Duplicate record found in the CSV based on the mapped identifying fields.'
                    });
                } else {
                    seenRows.add(duplicateKey);
                }
            }

            validRows++;
        });

        this.validationErrors = errors.slice(0, MAX_CLIENT_ERRORS);
        this.validationSummary = {
            totalRows: this.totalRows,
            validRows: Math.max(validRows - invalidRowNumbers.size, 0),
            errorCount: errors.length,
            errorMessage: errors.length
                ? `${errors.length} validation issue(s) found. No Salesforce records will be created until the errors are corrected.`
                : ''
        };
        this.hasValidationRun = true;

        if (errors.length === 0) {
            this.buildPreview();
            this.showToast('Success', 'CSV validation passed. Review the preview and start processing when ready.', 'success');
        } else {
            this.hasPreview = false;
            this.previewRows = [];
            this.previewColumns = [];
            this.showToast('Error', 'Validation failed. Correct the CSV/mapping issues before processing.', 'error');
        }
    }

    getTargetColumnLabels() {
        const mappedValues = Object.values(this.mapping);
        const labels = this.salesforceFieldOptions
            .filter((option) => mappedValues.includes(option.value))
            .map((option) => option.label);
 
        if (this.derivedRecordType === 'Account' && !labels.includes('Billing Country')) {
            labels.push('Billing Country');
        } else if (this.derivedRecordType === 'Contact' && !labels.includes('Mailing Country')) {
            labels.push('Mailing Country');
        }
        return labels;
    }

// CHANGED: now uses getTargetColumnLabels()
    buildPreview() {
        this.previewColumns = this.getTargetColumnLabels();
        this.previewRows = this.parsedRows
            .filter((row) => !this.isBlankRecord(row))
            .slice(0, PREVIEW_LIMIT)
            .map((row, index) => {
                const record = this.buildRecord(row);
                return {
                    key: `preview-${index}`,
                    cells: this.previewColumns.map((label, cellIndex) => ({
                        key: `cell-${index}-${cellIndex}`,
                        value: String(record[this.getFieldApiByLabel(label)] ?? '')
                    }))
                };
            });
 
        this.hasPreview = this.previewRows.length > 0;
    }
 
    getRecordLinkField() {
        return this.derivedRecordType === 'Contact' ? 'LastName' : 'Name';
    }
 
    getRecordUrl(recordId) {
        const objectApiName = this.derivedRecordType || 'Account';
        return `/lightning/r/${objectApiName}/${recordId}/view`;
    }
 
    addImportedRecords(records, createdRecords) {
        if (!createdRecords.length || this.importedRows.length >= IMPORTED_DISPLAY_LIMIT) {
            return;
        }
 
        if (!this.importedColumns.length) {
            this.importedColumns = this.getTargetColumnLabels();
        }
 
        const linkField = this.getRecordLinkField();
        // Link the Name column; fall back to the first column if Name isn't mapped
        const linkColumnIndex = Math.max(
            this.importedColumns.findIndex((label) => this.getFieldApiByLabel(label) === linkField),
            0
        );
 
        const newRows = createdRecords.map((created) => {
            const record = records[Number(created.rowIndex)] || {};
            const rowKey = `imported-${created.recordId}`;
 
            const cells = this.importedColumns.map((label, cellIndex) => {
            const value = String(record[this.getFieldApiByLabel(label)] ?? '');
            const isLink = cellIndex === linkColumnIndex;
            return {
                key: `${rowKey}-${cellIndex}`,
                value: isLink && !value ? created.recordId : value,
                url: isLink ? this.getRecordUrl(created.recordId) : null
            };
            });

            return {
                key: rowKey,
                searchName: String(cells[linkColumnIndex]?.value || '').toLowerCase(),
                cells
            };
        });
        
 
        this.importedRows = [...this.importedRows, ...newRows].slice(0, IMPORTED_DISPLAY_LIMIT);
    }

    startProcessing() {
        if (this.isStartDisabled) {
            this.showToast('Error', 'Please complete validation and resolve all errors before processing.', 'error');
            return;
        }

        this.isProcessing = true;
        this.showProgress = true;
        this.progress = 0;
        this.processedCount = 0;
        this.successCount = 0;
        this.failureCount = 0;
        this.importErrors = [];
        this.importedColumns = [];
        this.importedRows = []; 
        this.importedSearchTerm = '';

        this.processParsedRowsInChunks();
    }

    processParsedRowsInChunks() {
        const rows = this.parsedRows.filter((row) => !this.isBlankRecord(row));
        let index = 0;

        const processNextChunk = () => {
            if (index >= rows.length) {
                this.finishProcessing();
                return;
            }

            const rowsForChunk = rows.slice(index, index + CHUNK_SIZE);
            const records = rowsForChunk.map((row) => this.buildRecord(row));
            const startingRowNumber = this.getOriginalRowNumber(rowsForChunk[0]);
            this.currentChunkStartRowNumber = startingRowNumber;

            this.sendChunk(records)
                .then((result) => {
                    const response = result || {};
                    const successCount = Number(response.successCount || 0);
                    const failureCount = Number(response.failureCount || 0);
                    const errors = response.errors || [];

                    this.successCount += successCount;
                    this.failureCount += failureCount;

                    this.addImportedRecords(records, response.createdRecords || []);

                    this.importErrors = [
                        ...this.importErrors,
                        ...errors.map((error, errorIndex) => ({
                            key: `import-${startingRowNumber}-${index}-${errorIndex}`,
                            rowNumber: Number(error.rowNumber || startingRowNumber),
                            message: error.message || 'Record processing failed.'
                        }))
                    ].slice(0, MAX_CLIENT_ERRORS);

                    this.processedCount += rowsForChunk.length;
                    this.updateProgress(this.processedCount, rows.length);

                    index += rowsForChunk.length;
                    processNextChunk();
                })
                .catch((error) => {
                    // A transport/Apex exception is different from individual DML failures.
                    // We cannot safely continue if the whole chunk failed before Apex returned.
                    this.failureCount += rowsForChunk.length;
                    rowsForChunk.forEach((row, offset) => {
                        this.importErrors.push({
                            key: `transport-${startingRowNumber + offset}`,
                            rowNumber: startingRowNumber + offset,
                            message: this.getErrorMessage(error)
                        });
                    });
                    this.processedCount += rowsForChunk.length;
                    this.updateProgress(this.processedCount, rows.length);
                    this.showToast('Error', 'A processing error occurred. The remaining records were not submitted.', 'error');
                    this.isProcessing = false;
                    this.showProgress = true;
                });
        };

        processNextChunk();
    }

    buildRecord(row) {
        const record = {};
        const DATE_FIELDS = ['Birthdate'];

        Object.entries(this.mapping).forEach(([csvField, sfField]) => {
            if (!sfField) return;

            const rawValue = row[csvField];
            const value = rawValue === undefined || rawValue === null
                ? ''
                : String(rawValue).trim();

            record[sfField] = DATE_FIELDS.includes(sfField)
                ? this.normalizeDateField(value)
                : value;
        });

        const country = this.getCountryByReportType();
        if (country) {
            if (this.derivedRecordType === 'Account') {
                record.BillingCountry = country;
            } else {
                record.MailingCountry = country;
            }
        }

        if (this.derivedRecordType === 'Contact') {
            const middleNameKey = Object.keys(row).find(
                (key) => this.normalize(key) === 'middlename'
            );

            if (middleNameKey && String(row[middleNameKey] || '').trim()) {
                const middle = String(row[middleNameKey]).trim();
                record.FirstName = record.FirstName
                    ? `${record.FirstName} ${middle}`
                    : middle;
            }

            const mailingStreetKeys = Object.keys(row).filter((key) =>
                [
                    'streetnumber',
                    'streetname',
                    'streettypedirectionalapartmentnumber'
                ].includes(this.normalize(key))
            );

            const streetValue = mailingStreetKeys
                .map((key) => String(row[key] || '').trim())
                .filter(Boolean)
                .join(' ');

            if (streetValue) {
                record.MailingStreet = streetValue;
            }
        }

        return record;
    }

    sendChunk(chunk) {
        return this.derivedRecordType === 'Contact'
            ? createContacts({ contacts: chunk, startingRowNumber: this.currentChunkStartRowNumber || 2 })
            : createAccounts({
                accounts: chunk,
                creditPolicyRecordID: this.creditPolicyRecordID,
                startingRowNumber: this.currentChunkStartRowNumber || 2
            });
    }

    updateProgress(processed, total) {
        if (!total) {
            this.progress = 0;
            return;
        }

        this.progress = Math.min(
            Math.round((processed / total) * 100),
            99
        );
    }

    finishProcessing() {
        this.progress = 100;
        this.isProcessing = false;

        if (this.failureCount > 0) {
            this.showToast(
                'Warning',
                `Import completed with ${this.successCount} successful and ${this.failureCount} failed record(s).`,
                'warning'
            );
        } else if (!this.skipReportPull) {
            this.startBatch();
        } else {
            this.showToast('Success', `Upload completed successfully. ${this.successCount} record(s) created.`, 'success');
        }
    }

    startBatch() {
        startReportProcessingBatch({ picklistValue: this.selectedOption })
            .then(() => {
                this.showToast(
                    'Success',
                    `Upload completed. ${this.successCount} record(s) created and report processing batch started.`,
                    'success'
                );
            })
            .catch((error) => {
                this.showToast(
                    'Warning',
                    `Upload completed, but the report processing batch could not be started: ${this.getErrorMessage(error)}`,
                    'warning'
                );
            });
    }

    normalizeDateField(value) {
        if (!value) return null;

        const trimmed = String(value).trim();

        const dashMatch = trimmed.match(/^(\d{1,2})-(\d{1,2})-(\d{4})$/);
        if (dashMatch) {
            const [, month, day, year] = dashMatch;
            return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
        }

        const slashMatch = trimmed.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
        if (slashMatch) {
            const [, month, day, year] = slashMatch;
            return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
        }

        return trimmed;
    }

    isValidSalesforceDate(value) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
        const date = new Date(`${value}T00:00:00Z`);
        return !Number.isNaN(date.getTime()) &&
            date.toISOString().slice(0, 10) === value;
    }

    getDuplicateRowKey(record) {
        if (this.derivedRecordType === 'Account') {
            const idField = record.forseva1__Equifax_File_Number__c ||
                record.forseva1__Tax_Id__c;
            return idField ? `A:${String(idField).toLowerCase()}` : null;
        }

        const lastName = record.LastName;
        const phone = record.Phone;
        return lastName && phone
            ? `C:${String(lastName).toLowerCase()}|${String(phone).toLowerCase()}`
            : null;
    }

    getOriginalRowNumber(row) {
        const index = this.parsedRows.indexOf(row);
        return index >= 0 ? index + 2 : 2;
    }

    isBlankRecord(row) {
        return Object.values(row || {}).every(
            (value) => value === null || value === undefined || String(value).trim() === ''
        );
    }

    findDuplicateHeaders(headers) {
        const seen = new Set();
        const duplicates = new Set();

        headers.forEach((header) => {
            const normalized = this.normalize(header);
            if (seen.has(normalized)) duplicates.add(header);
            seen.add(normalized);
        });

        return Array.from(duplicates);
    }

    getFieldLabel(apiName) {
        const option = this.salesforceFieldOptions.find(
            (item) => item.value === apiName
        );
        return option ? option.label : apiName;
    }

    getFieldApiByLabel(label) {
        const option = this.salesforceFieldOptions.find(
            (item) => item.label === label
        );
        if (option) return option.value;

        if (label === 'Billing Country') return 'BillingCountry';
        if (label === 'Mailing Country') return 'MailingCountry';
        return label;
    }

    normalize(value) {
        return String(value || '')
            .toLowerCase()
            .replace(/[\s_\-./()]/g, '');
    }

    resetValidationAndResults() {
        this.hasValidationRun = false;
        this.hasPreview = false;
        this.validationErrors = [];
        this.validationSummary = {
            totalRows: this.totalRows,
            validRows: 0,
            errorCount: 0,
            errorMessage: ''
        };
        this.previewRows = [];
        this.previewColumns = [];
        this.importedColumns = [];
        this.importedRows = [];
        this.importedSearchTerm = '';
        this.importErrors = [];
        this.processedCount = 0;
        this.successCount = 0;
        this.failureCount = 0;
        this.showProgress = false;
        this.progress = 0;
    }

    resetFileState() {
        this.file = null;
        this.fileName = '';
        this.csvHeaders = [];
        this.mappingRows = [];
        this.mapping = {};
        this.parsedRows = [];
        this.totalRows = 0;
        this.currentChunkStartRowNumber = 2;
        this.selectedTemplateId = '';
        this.currentTemplateMapping = null;
        this.resetValidationAndResults();

        const fileInput = this.template.querySelector('lightning-input[type="file"]');
        if (fileInput) {
            fileInput.value = null;
        }
    }

    getErrorMessage(error) {
        return error?.body?.message ||
            error?.message ||
            'An unexpected error occurred.';
    }

    showToast(title, message, variant) {
        this.dispatchEvent(
            new ShowToastEvent({ title, message, variant })
        );
    }

    openApexJobsPage() {
        const jobsUrl = `${window.location.origin}/lightning/setup/AsyncApexJobs/home`;

        const link = document.createElement('a');
        link.href = jobsUrl;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    handleResetScreen() {
        this.selectedOption = null;
        this.creditPolicyRecordID = null;
        this.salesforceFieldOptions = [];
        this.templateOptions = [];
        this.skipReportPull = false;

        this.resetFileState();

        this.showToast('Success', 'Screen has been reset.', 'success');
    }
}