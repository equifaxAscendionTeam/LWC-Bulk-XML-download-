import { LightningElement, api } from 'lwc';
import { CloseActionScreenEvent } from 'lightning/actions';
import { notifyRecordUpdateAvailable } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class Pe_FlowRecordAction extends LightningElement {
    flowApiName = 'Estimate_Agent';
    @api recordId;

    message = 'Generating estimate… this can take a moment.';

    get inputVariables() {
        return [{ name: 'recordId', type: 'String', value: this.recordId }];
    }

    async handleStatusChange(event) {
        const status = event.detail.status;

        if (status === 'STARTED') {
            this.message = 'Agent is analysing the BRD…';
        }

        if (status === 'FINISHED' || status === 'FINISHED_SCREEN') {
            this.message = 'Done — refreshing the record…';

            // refresh the record page fields (Hours Estimated, Estimate JSON, etc.)
            await notifyRecordUpdateAvailable([{ recordId: this.recordId }]);

            this.dispatchEvent(new ShowToastEvent({
                title: 'Estimate complete',
                message: 'The estimate has been generated and saved.',
                variant: 'success'
            }));

            this.dispatchEvent(new CloseActionScreenEvent());
        }

        if (status === 'ERROR') {
            this.dispatchEvent(new ShowToastEvent({
                title: 'Estimate failed',
                message: 'The flow did not finish. Check the flow error email or debug logs.',
                variant: 'error'
            }));
            this.dispatchEvent(new CloseActionScreenEvent());
        }
    }
}