import { LightningElement } from 'lwc';
export default class Pe_BRDFileUploader extends LightningElement {

}