import { LightningElement } from 'lwc';
import { loadScript } from 'lightning/platformResourceLoader';

import JSZIP from '@salesforce/resourceUrl/JSZip';

import getXmlBatch
    from '@salesforce/apex/ConsumerXmlDownloadController.getXmlBatch';

import getXmlCount
    from '@salesforce/apex/ConsumerXmlDownloadController.getXmlCount';

export default class ConsumerXmlDownloaderLwc extends LightningElement {

    startDate;
    endDate;

    isLoading = false;
    message = '';

    jsZipInitialized = false;

    renderedCallback() {
        if (this.jsZipInitialized) {
            return;
        }

        this.jsZipInitialized = true;

        loadScript(this, JSZIP)
            .then(() => {
                this.message = 'ZIP library loaded.';
            })
            .catch((error) => {
                this.message =
                    'ZIP library failed to load: ' +
                    this.getErrorMessage(error);
            });
    }

    handleStartDateChange(event) {
        this.startDate = event.target.value;
    }

    handleEndDateChange(event) {
        this.endDate = event.target.value;
    }

    async handleDownload() {

        if (!this.startDate || !this.endDate) {
            this.message =
                'Select Start Date and End Date.';
            return;
        }

        if (this.startDate > this.endDate) {
            this.message =
                'Start Date cannot be after End Date.';
            return;
        }

        if (typeof JSZip === 'undefined') {
            this.message =
                'ZIP library is not loaded.';
            return;
        }

        this.isLoading = true;

        this.message =
            'Counting matching XML files...';

        try {

            const totalRecords =
                await getXmlCount({
                    startDate: this.startDate,
                    endDate: this.endDate
                });

            if (totalRecords === 0) {
                this.message =
                    'No XML files found for the selected dates.';
                return;
            }

            const startTime =
                Date.now();

            this.message =
                'Found ' +
                totalRecords +
                ' XML files. Starting download...';

            const zip =
                new JSZip();

            let totalFiles = 0;

            let lastCreatedDate = null;
            let lastReportId = null;

            let hasMore = true;

            while (hasMore) {

                const batch =
                    await getXmlBatch({
                        startDate:
                            this.startDate,

                        endDate:
                            this.endDate,

                        lastCreatedDate:
                            lastCreatedDate,

                        lastReportId:
                            lastReportId
                    });

                const files =
                    batch.files || [];

                files.forEach((file) => {

                    zip.file(
                        file.fileName,
                        file.base64Content,
                        {
                            base64: true
                        }
                    );

                });

                totalFiles +=
                    files.length;

                const elapsedSeconds =
                    (Date.now() - startTime) / 1000;

                const progress =
                    Math.min(
                        100,
                        (totalFiles / totalRecords) * 100
                    );

                let etaSeconds = 0;

                if (totalFiles > 0) {
                    etaSeconds =
                        (elapsedSeconds / totalFiles) *
                        (totalRecords - totalFiles);
                }

                this.message =
                    'Processed: ' +
                    totalFiles +
                    ' / ' +
                    totalRecords +
                    ' (' +
                    progress.toFixed(1) +
                    '%) | Elapsed: ' +
                    this.formatTime(elapsedSeconds) +
                    ' | ETA: ' +
                    this.formatTime(etaSeconds);

                hasMore =
                    batch.hasMore;

                lastCreatedDate =
                    batch.nextCreatedDate;

                lastReportId =
                    batch.nextReportId;

                if (
                    hasMore &&
                    (
                        !lastCreatedDate ||
                        !lastReportId
                    )
                ) {
                    throw new Error(
                        'Batch cursor was not returned.'
                    );
                }
            }

            if (totalFiles === 0) {
                this.message =
                    'No XML files found for the selected dates.';

                return;
            }

            this.message =
                'Creating ZIP with ' +
                totalFiles +
                ' XML files...';

            const content =
                await zip.generateAsync({
                    type: 'blob'
                });

            const totalSeconds =
                (Date.now() - startTime) / 1000;

            this.downloadZip(
                content,
                totalFiles,
                totalSeconds
            );

        } catch (error) {

            this.message =
                'Download failed: ' +
                this.getErrorMessage(error);

        } finally {

            this.isLoading = false;

        }
    }

    downloadZip(
        content,
        totalFiles,
        totalSeconds
    ) {

        const now =
            new Date();

        const timestamp =
            now.getFullYear() +
            '-' +
            String(
                now.getMonth() + 1
            ).padStart(2, '0') +
            '-' +
            String(
                now.getDate()
            ).padStart(2, '0') +
            '_' +
            String(
                now.getHours()
            ).padStart(2, '0') +
            '-' +
            String(
                now.getMinutes()
            ).padStart(2, '0') +
            '-' +
            String(
                now.getSeconds()
            ).padStart(2, '0');

        const fileName =
            'Consumer_XML_' +
            timestamp +
            '.zip';

        const url =
            URL.createObjectURL(
                content
            );

        const link =
            document.createElement(
                'a'
            );

        link.href =
            url;

        link.download =
            fileName;

        document.body.appendChild(
            link
        );

        link.click();

        setTimeout(() => {
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
        }, 1000);

        this.message =
            'Completed: ' +
            totalFiles +
            ' XML files | Total time: ' +
            this.formatTime(totalSeconds) +
            ' | ZIP download complete.';
    }
    formatTime(seconds) {

        seconds =
            Math.max(
                0,
                Math.round(seconds)
            );

        const minutes =
            Math.floor(
                seconds / 60
            );

        const remainingSeconds =
            seconds % 60;

        if (minutes === 0) {
            return remainingSeconds + 's';
        }

        return (
            minutes +
            'm ' +
            remainingSeconds +
            's'
        );
    }
    getErrorMessage(error) {

        if (
            error &&
            error.body &&
            error.body.message
        ) {
            return error.body.message;
        }

        if (
            error &&
            error.message
        ) {
            return error.message;
        }

        return 'Unknown error.';
    }
}